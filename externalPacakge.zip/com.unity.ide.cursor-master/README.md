# How to install
<br>
- Unity->Window->Package Manager<br>
- Click "+" left corner<br>
- Add package from git URL<br>
- Insert <code>https://github.com/boxqkrtm/com.unity.ide.cursor.git</code><br>
- Add<br>
- Done
